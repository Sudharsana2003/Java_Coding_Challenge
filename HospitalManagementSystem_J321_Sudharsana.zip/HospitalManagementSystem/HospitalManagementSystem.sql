#1.Create a Database
create database hospitalmanagement;

#2.Use the database created
use hospitalmanagement;

#3.Creation of tables

#3.1 Patient
CREATE TABLE Patient (
    patientId INT PRIMARY KEY AUTO_INCREMENT,
    firstName VARCHAR(255),
    lastName VARCHAR(255),
    dateOfBirth VARCHAR(255),
    gender VARCHAR(10),
    contactNumber VARCHAR(20),
    address VARCHAR(255)
);

#3.2 Doctor
CREATE TABLE Doctor (
    doctorId INT PRIMARY KEY AUTO_INCREMENT,
    firstName VARCHAR(255),
    lastName VARCHAR(255),
    specialization VARCHAR(255),
    contactNumber VARCHAR(20)
);

#3.3 Appointment
CREATE TABLE Appointment (
    appointmentId INT PRIMARY KEY AUTO_INCREMENT,
    patientId INT,
    doctorId INT,
    appointmentDate DATETIME,
    description VARCHAR(255),
    FOREIGN KEY (patientId) REFERENCES Patient(patientId),
    FOREIGN KEY (doctorId) REFERENCES Doctor(doctorId)
);


#4.Insertion of Samples

#4.1 Patient
INSERT INTO Patient (firstName, lastName, dateOfBirth, gender, contactNumber, address) VALUES
('Aarav', 'Sharma', '1995-08-15', 'Male', '9876543210', '12, Park Street, Delhi'),
('Sneha', 'Patel', '1988-03-22', 'Female', '8765432109', '45, MG Road, Mumbai'),
('Rahul', 'Singh', '2001-11-01', 'Male', '7654321098', '78, Anna Nagar, Chennai'),
('Priya', 'Kumar', '1976-06-10', 'Female', '6543210987', '101, Brigade Road, Bangalore'),
('Vikram', 'Reddy', '1990-12-25', 'Male', '5432109876', '23, Banjara Hills, Hyderabad');

#4.2 Doctor
INSERT INTO Doctor (firstName, lastName, specialization, contactNumber) VALUES
('Anika', 'Verma', 'Cardiology', '9988776655'),
('Rajesh', 'Menon', 'Dermatology', '8899001122'),
('Sunita', 'Chopra', 'Pediatrics', '7766554433'),
('Karthik', 'Nair', 'Orthopedics', '6655443322'),
('Deepa', 'Joshi', 'Neurology', '5544332211');

#4.3 Appointment
INSERT INTO Appointment (patientId, doctorId, appointmentDate, description) VALUES
(1, 1, '2023-11-20 10:00:00', 'Cardiac checkup'),
(2, 2, '2023-11-21 14:00:00', 'Skin allergy consultation'),
(3, 3, '2023-11-22 11:30:00', 'Child vaccination'),
(4, 4, '2023-11-23 15:30:00', 'Knee pain assessment'),
(5, 5, '2023-11-24 09:00:00', 'Neurological evaluation'),
(1, 2, '2023-11-25 11:00:00', 'Follow-up skin check'),
(3, 1, '2023-11-26 13:00:00', 'Pediatric cardiac review');